#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h> // inet_ntoa, inet_addr
#include <netinet/in.h> // IPPROTO_ICMP
#include <netinet/ip_icmp.h> // stuct icmp
#include <netinet/ether.h>
#include <netinet/ip.h>     // struct ip
// #include <netinet/udp.h>
#include <netinet/tcp.h>
#include <linux/if_packet.h>


#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define TARGET_IP "10.0.2.4"
#define SIZEOF_PACKET sizeof(struct iphdr) + sizeof(struct icmphdr)

/**
 *  Generic Checksum Calculation Function. Function taken from https://www.binarytides.com/raw-udp-sockets-c-linux/
 */ 
unsigned short chksum(unsigned short *ptr, int nbytes){
    /**Register keyword tells compiler to store the particular variable 
     * in CPU registers so that it could be accessible fast. From a 
     * programmer's point of view register keyword is used for the variables 
     * which are heavily used in a program, so that compiler can speedup the code
     */
    int sum = 0;
    unsigned short answer = 0;

    while(nbytes > 1){
        sum+=*ptr++;
        nbytes-=2;
    }
    if(nbytes==1){
        *((unsigned char*)&answer)=*(unsigned char*)ptr;
        sum+=answer;
    }
    sum = (sum>>16) + (sum&0xFFFF);
    sum = sum + (sum>>16);

    answer = ~sum;
    return answer;
}

int main(int argc, char* argv[]){
    char * SPOOF_IP;
    if (argc != 2) {
        printf("Usage: %s <IP_ADDR>\n",argv[0]);
        exit(-1);
    }
    else {
        SPOOF_IP = argv[1];
		if (*SPOOF_IP == INADDR_NONE) {
            perror("Please enter a valid IP Address!");
            exit(-1);
        }
    }
    //Datagram to represent the packet
	unsigned char packet[SIZEOF_PACKET], *data; // 8 bits act as additional buffer
    struct sockaddr_in sin;

    //zero out the packet buffer
	memset (packet, 0, SIZEOF_PACKET);

    /* --== Address Resolution ==-- */
    /* This data structure is needed when sending the packets
    *	using sockets. Normally, we need to fill out several
    *	fields, but for raw sockets, we only need to fill out
    *	this one field */ 
    sin.sin_family = AF_INET;

    /* --== IP HEADER at start of packet==-- */
    struct iphdr *iph = (struct iphdr *) packet;

    /* --== ICMP HEADER after IP Header ==-- */
	struct icmphdr *icmph = (struct icmphdr *) (packet + sizeof (struct iphdr));

    /* --== FILL UP IP HEADER (LAYER II)==-- */
    iph->ihl=0x5;               /* header length = 5 */
    iph->version=0x4;           /* IPv4 */
	iph->tos= 0x0;              /* typ of service */
    iph->tot_len=SIZEOF_PACKET;
    iph->id=1;                  /* unique field identify each data sent by this host */
    iph->frag_off=0;            /* 0 = off fragment */
    iph->ttl=64;                /* time to live */
    iph->protocol=IPPROTO_ICMP;
    iph->check=0x0;             /* this checksum is only checked after the IP header is done */
    iph->saddr=inet_addr(SPOOF_IP);
    iph->daddr=inet_addr (TARGET_IP);

    /* get new checksum after instantiating the ipheader */
    iph->check = chksum((unsigned short *)&iph, sizeof(iph));

    /* --== FILL UP IP HEADER (LAYER III)==-- */
    icmph->type = ICMP_ECHO;                 /* ECHO ICMP type */
    icmph->code = 0;                         /* ECHO Request code */
    icmph->checksum = 0;                     /* same as IP header, initiate at 0 first */
    icmph->un.echo.id = htons(12345);        /* can be a random number. htons() is used to transform to big endian */
    icmph->un.echo.sequence = htons(0x0);    
    icmph->checksum = htons(chksum((unsigned short *)&icmph, 8));

    sin.sin_addr.s_addr = iph->daddr;

    /** 
     * Create a raw socket with IP protocol. The IPPROTO_RAW parameter
     * tells the sytem that the IP header is already included;
     * this prevents the OS from adding another IP header.	
     */ 
    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    if (sock < 0) {
        perror("[ERROR] socket() failed"); 
        exit(-1);
    }
    /* Send out the IP packet.
    *	ip_len is the actual size of the packet. */ 
   if (sendto(sock, packet, SIZEOF_PACKET, 0, (struct sockaddr *)&sin, sizeof(struct sockaddr)) < 0) {
        perror("[ERROR] sendto() failed"); 
        exit(-1);
    }
    //Data send successfully
    else {
        printf ("Packet Sent. Length : %d \n" , iph->tot_len);
    }

}
